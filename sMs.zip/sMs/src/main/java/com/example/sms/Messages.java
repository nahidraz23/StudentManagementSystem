package com.example.sms;

public class Messages {
    public static String text = "";
}
